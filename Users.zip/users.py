from requests import post
from datetime import datetime
from csv import reader

from flask import *
from re import compile
import json
import ast

#Create a count.txt before running

app = Flask(__name__)

orchestrator = "http://54.157.24.79:80"


def count():
    f = open("count.txt","r")
    requestsCount = f.read()
    f.close()

    f=open("count.txt", "w")
    requestsCount = int(requestsCount) + 1
    f.write(str(requestsCount))
    f.close()

@app.route('/api/v1/_count', methods=["GET"])
def count_of_requests():
    f = open("count.txt", "r")
    requestsCount = f.read()
    f.close()

    return '[' + requestsCount + ']'

@app.route('/api/v1/_count', methods=["DELETE"])
def reset_requests():
    f=open("count.txt", "w")
    f.write("0")
    f.close()
    return "{}"

@app.route('/api/v1/users', methods=["PUT"])
def add_user():
    count()

    rjson = request.get_json()
    rkeys = list(rjson.keys())

    if not rjson:
        return Response("invalid request", 400)
    elif not "username" in rkeys:
        return Response("invalid username", 400)
    elif not "password" in rkeys:
        return Response("invalid password", 400)
    password = rjson['password']
    pattern = compile(r'\b[0-9a-fA-F]{40}\b')
    match = pattern.match(password)

    if not match:
        return Response("invalid request", 400)

    data = {"username": rjson["username"]}
    wjson = {"data": data, "table": "user", "action": "check"}

    read = post(orchestrator+"/api/v1/db/read", json=wjson)

    if int(read.text) == 1:
        return Response('user already exists!', 400)
    wjson = {"data": rjson, "table": "user", "action": "add"}
    wjson["data"]["ride"] = ""
    write = post(orchestrator+"/api/v1/db/write", json=wjson)
    return Response("{}", status=201, mimetype="application/json")
    

@app.route('/api/v1/users/<username>', methods=["DELETE"])
def remove_user(username):
    count()

    data = {"username": username}
    wjson = {"data": data, "table": "user", "action": "check"}

    read = post(orchestrator+"/api/v1/db/read", json=wjson)

    if int(read.text) == 1:
        wjson = {"data": data, "table": "user", "action": "delete"}
        write = post(orchestrator+"/api/v1/db/write", json=wjson)
        if str(write.text) == "{}":
            respString = 'user '+username+' has been removed'
            return Response(respString, 200)
        else:
            return Response('error occured while removing user', 400)
    return Response('user not found', 400)

@app.route('/api/v1/users', methods=["GET"])
def list_users():
    count()
    wjson = {"table": "user", "action": "list"}
    read = post(orchestrator+"/api/v1/db/read", json=wjson)

    print(ast.literal_eval(read.text))
    if ast.literal_eval(read.text) == [] :
        return Response('no users', 204)

    try:
        read.json()
    except ValueError as e:
        return Response('no users', 204)

    return jsonify(read.json())


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)

