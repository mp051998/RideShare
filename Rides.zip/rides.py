from requests import post
from requests import get
from datetime import datetime
from csv import reader
import ast
import json

from flask import *
from re import compile

app = Flask(__name__)

#Create a count.txt before running
#Create a ridesCount.txt before running

enums = list()
with open('AreaNameEnum.csv') as csv_file:
    csv_reader = reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            line_count = 1
            continue
        enums.append(row[0].lower())

#users_ip = get("https://checkip.amazonaws.com").text[:-1]+":8080"
#users_ip = "CC-1513195356.us-east-1.elb.amazonaws.com"
orchestrator = "http://54.157.24.79:80"

def count():
    f = open("count.txt","r")
    requestsCount = f.read()
    f.close()

    f=open("count.txt", "w")
    requestsCount = int(requestsCount) + 1
    f.write(str(requestsCount))
    f.close()

@app.route('/api/v1/_count', methods=["GET"])
def count_of_requests():
    f= open("count.txt","r")
    requestsCount = f.read()
    f.close()
    return '[' + requestsCount + ']'

@app.route('/api/v1/_count', methods=["DELETE"])
def reset_requests():
    f = open("count.txt", "w")
    f.write("0")
    f.close()
    return "{}"

@app.route('/api/v1/rides/count', methods=["GET"])
def rides_count():
    f = open("ridesCount.txt", "r")
    ridesCount = f.read()
    return '[' + ridesCount + ']'


@app.route('/api/v1/rides', methods=["POST"])
def create_new_ride():
    count()

    rjson = request.get_json()
    rkeys = list(rjson.keys())
    
    if not rjson:
        return "invalid request", 400
    elif not "created_by" in rkeys:
        return "invalid created_by", 400
    elif not "timestamp" in rkeys:
        return "invalid timestamp", 400
    elif not "source" in rkeys:
        return "invalid source", 400
    elif not "destination" in rkeys:
        return "invalid destination", 400

    data = {"username" : rjson["created_by"]}
    wjson = {"data" : data, "table" : "user", "action" : "check"}
    read = post(orchestrator+"/api/v1/db/read", json=wjson)
    if not int(read.text) == 1:
        return Response('user not found', 400)
    dtimestamp = 0
    try:
        dtimestamp =  datetime.strptime(rjson["timestamp"], "%d-%m-%Y:%S-%M-%H")
    except ValueError:
        return 'invalid timestamp', 400

    rjson['source'] = rjson['source'].lower()
    rjson['destination'] = rjson['destination'].lower()

    if not rjson['source'] in enums:
        return 'invalid source', 400
    elif not rjson['destination'] in enums:
        return 'invalid destination', 400
    elif rjson['source'] == rjson['destination']:
        return 'source and destination cannot be same', 400

    data = rjson
    data["members"] = list()
    data["members"].append(data["created_by"])

    wjson = dict()
    wjson = {"data" : data, "table" : "ride", "action" : "create"}

    write = post(orchestrator+"/api/v1/db/write", json=wjson)
    if str(write.text) == "{}":
        return Response('ride created successfully', 201)
    return Response('database error', 500)
    
    f = open("ridesCount.txt", "r")
    ridesCount = f.read()
    f.close()
    ridesCount = int(ridesCount) + 1

    f = open("ridesCount.txt", "w")
    f.write(str(ridesCount))
    f.close()


@app.route('/api/v1/rides', methods=["GET"])
def list_rides():
    count()

    source = request.args.get('source')
    if not source:
        return 'invalid source request', 400

    destination = request.args.get('destination')
    if not destination:
        return 'invalid destination request', 400

    source = int(source)
    if source > len(enums):
        return 'invalid source request', 400
 
    destination = int(destination)
    if destination > len(enums):
        return 'invalid destination request', 400

    source = enums[source-1]
    destination = enums[destination-1]

    data = {"source" : source, "destination" : destination}
    wjson = {"data" : data, "table" : "ride", "action" : "list"}

    read = post(orchestrator+"/api/v1/db/read", json=wjson)
    
    try:
        read.json()
    except ValueError as e:
        return Response('no rides', 204)
    if len(read.json()) == 0:
        return Response('no rides', 204)
    return jsonify(read.json())


@app.route('/api/v1/rides/<rideId>', methods=["GET"])
def get_details(rideId):
    count()

    wjson = {"data" : rideId, "table" : "ride", "action" : "get"}
    read = post(orchestrator+"/api/v1/db/read", json=wjson)

    try:
        if int(read.text) == 0:
            return Response('no ride with id '+str(rideId), 400)
        else:
            try:
                read.json()
            except ValueError as e:
                return Response('no ride with id '+str(rideId), 400)
    except:
        pass

    return Response(json.dumps(read.json()), 200)
    return jsonify(read.json()), 200


@app.route('/api/v1/rides/<rideId>', methods=["POST"])
def join_ride(rideId):
    count()

    wjson = {"data" : rideId, "table" : "ride", "action" : "get"}
    read = post(orchestrator+"/api/v1/db/read", json=wjson)
    
    found = 0
    try:
        if int(read.text) == 0:
            return Response('no ride with id '+str(rideId), 400)
    except:
        found = 1
 
    rjson = request.get_json()
    rkeys = list(rjson.keys())
    
    if not rjson:
        return Response("invalid request", 400)
    elif not "username" in rkeys:
        return Response("invalid username", 400)

    data = rjson
    data["id"] = rideId
    wjson = {"data" : data, "table" : "ride", "action" : "is_member"}
    read = post(orchestrator+"/api/v1/db/read", json=wjson)
    if int(read.text) == 1:
        return Response('already member of ride', 400)

    wjson = {"data" : data, "table" : "ride", "action" : "join"}
    write = post(orchestrator+"/api/v1/db/write", json=wjson)

    if str(write.text) == "{}":
        return 'database error', 500

    return Response('join successful', 200)


@app.route('/api/v1/rides/<rideId>', methods=["DELETE"])
def delete_ride(rideId):
    count()

    wjson = {"data" : rideId, "table" : "ride", "action" : "get"}
    read = post(orchestrator+"/api/v1/db/read", json=wjson)
    if read.status_code == 404:
        return f'no ride with id {rideId} found', 400


    wjson = {"data" : rideId, "table" : "ride", "action" : "delete"}
    write = post(orchestrator+"/api/v1/db/write", json=wjson)

    if int(write.text==1):
    #if write.status_code == 500:
        #return 'database error', 500
        return Response('ride '+rideId+' has been deleted', 200)

    f = open("ridesCount.txt", "r")
    ridesCount = f.read()
    f.close()
    ridesCount = int(ridesCount) - 1

    f = open("ridesCount.txt", "w")
    f.write(str(ridesCount))
    f.close()
    
    return '', 200

if __name__ == "__main__":
    app.run(host = "0.0.0.0", debug=True)