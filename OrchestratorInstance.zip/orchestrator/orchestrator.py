#!/usr/bin/env python
import pika
import uuid
import json
import time
import requests
from flask import Flask, render_template, jsonify, request, abort, url_for, Response, jsonify
import uuid
import docker
import logging
from kazoo.client import KazooClient
from kazoo.client import KazooState
from waitress import serve
import threading
import os

time.sleep(15)

no_of_request = 0
running_slave_container = 1

slave_count = 1

first_request = 1

### Check the usage every 120 seconds ###
def usage_check():
	global no_of_request
	print("Usage:",no_of_request,"	Running Contianers:",running_slave_container)

	if running_slave_container < (no_of_request // 20) + 1:
		scale_up((no_of_request // 20)-running_slave_container+1)
	if running_slave_container > (no_of_request // 20) + 1:
		scale_down(running_slave_container - (no_of_request // 20)-1)

	timer = threading.Timer(118.0, usage_check)
	timer.start()
	no_of_request = 0

client = docker.DockerClient(base_url='unix://var/run/docker.sock')

def scale_up(amt):
	global slave_count
	global running_slave_container
	print("[*] Scaling Up..",amt)
	for i in range(amt):
		running_slave_container = running_slave_container + 1
		slave_container = client.containers.run(
			"ubuntu_slave", 
			name="slave_"+str(slave_count+1), 
			network = "ubuntu_cc", 
			links={'zoo':'zoo','master-rabbitmq':'master-rabbitmq'},
			environment=["slave=slave_"+str(slave_count+1)],
			detach = True)
		slave_count = slave_count + 1
		print("[*] Container created",slave_container)
	while True:
		y = zk.get_children("/slave")
		if len(y) == running_slave_container:
			break


def scale_down(amt):
	global slave_count
	global running_slave_container
	containers_list = client.containers.list()
	slaves = []
	for container in containers_list:
		slave = container
		pid = container.top()['Processes'][0][1]
		cmd  = 	container.top()['Processes'][0][7]
		if 'slave' in str(cmd):
			slaves.append((pid,slave))
	slaves.sort()
	print("[*] Scaling down..",amt,len(slaves))
	for i in range(amt):
		container = slaves[0][1]
		running_slave_container = running_slave_container - 1
		container.stop()
		slaves = slaves[1:]

print("before zk.start")



zk = KazooClient(hosts='zoo:2181')
zk.start()
zk.ensure_path("/slave")

print("after zk.start")

def create_new_slave(event):
	global slave_count
	global running_slave_container
	children = zk.get_children('/slave')
	#if the children has failed. We create more ...
	print("[INFO] checking nodes..",len(children),running_slave_container)
	if(len(children) < running_slave_container):
		print("Creating a new node")
		slave_container = client.containers.run(
			"ubuntu_slave", 
			name="slave_"+str(slave_count+1), 
			network = "ubuntu_cc", 
			links={'zoo':'zoo','master-rabbitmq':'master-rabbitmq'},
			environment=["slave=slave_"+str(slave_count+1)],
			detach = True)
		#slave_container.start()
		slave_count = slave_count + 1
		slave_container.attach(stdout=True)
		#slave_container = client.containers.run(image," ",detach = True)
		print("[INFO] New Slave Container stared",slave_container,slave_container.name)
		zk.get_children("/slave",watch=create_new_slave)
	else:
		zk.get_children("/slave",watch=create_new_slave)

print("before while")

zk.ensure_path("/slave")
### slaves watching the master.
while True:
	try:
		y = zk.get_children("/slave")
		if len(y) > 0:
			break
	except:
		continue

print("after while")

children = zk.get_children("/slave", watch=create_new_slave)


class ReadRpcClient(object):
	def __init__(self):
		self.connection = pika.BlockingConnection(
			pika.ConnectionParameters(host='master-rabbitmq', heartbeat=0))
		self.channel = self.connection.channel()

		result = self.channel.queue_declare(queue='responseQ', durable=True)
		self.callback_queue = result.method.queue

		self.channel.basic_consume(
			queue=self.callback_queue,
			on_message_callback=self.on_response,
			auto_ack=True)

	def on_response(self, ch, method, props, body):
		print("RPC Response")
		print(body)
		if self.correlation_id == props.correlation_id:
			self.response = body
			ch.basic_ack(delivery_tag=method.delivery_tag)

	def call(self, data):
		self.response = None
		self.correlation_id = str(uuid.uuid4())
		self.channel.queue_declare(queue='readQ',durable=True)
		self.channel.basic_publish(
			exchange='',
			routing_key='readQ',
			properties=pika.BasicProperties(
				reply_to=self.callback_queue,
				correlation_id=self.correlation_id,
			),
			body=data)
		while self.response is None:
			self.connection.process_data_events()
		return json.loads(self.response)

class WriteRpcClient(object):
	def __init__(self):
		self.connection = pika.BlockingConnection(
			pika.ConnectionParameters(host='master-rabbitmq', heartbeat=0))
		self.channel = self.connection.channel()

		result = self.channel.queue_declare(queue='responseQ', durable=True)
		self.callback_queue = result.method.queue

		self.channel.basic_consume(
			queue=self.callback_queue,
			on_message_callback=self.on_response,
			auto_ack=True)

	def on_response(self, ch, method, props, body):
		print("RPC Response")
		print(body)
		if self.correlation_id == props.correlation_id:
			self.response = body
			ch.basic_ack(delivery_tag=method.delivery_tag)

	def call(self, data):
		self.response = None
		self.correlation_id = str(uuid.uuid4())
		self.channel.queue_declare(queue='writeQ',durable=True)
		self.channel.basic_publish(
			exchange='',
			routing_key='writeQ',
			properties=pika.BasicProperties(
				reply_to=self.callback_queue,
				correlation_id=self.correlation_id,
			),
			body=data)
		while self.response is None:
			self.connection.process_data_events()
		return (self.response)
	
class ClearRpcClient(object):
	def __init__(self):
		self.connection = pika.BlockingConnection(
			pika.ConnectionParameters(host='master-rabbitmq', heartbeat=0))
		self.channel = self.connection.channel()

	def call(self, data):
		self.response = None
		self.correlation_id = str(uuid.uuid4())
		self.channel.queue_declare(queue='clearQ',durable=True)
		self.channel.basic_publish(
			exchange='',
			routing_key='clearQ',
			properties=pika.BasicProperties(
				correlation_id=self.correlation_id,
			),
			body=data)
		time.sleep(1)

app = Flask(__name__)

@app.route('/api/v1/db/read', methods = ['POST'])
def db_read():
    rjson = request.get_json()
    obj = ReadRpcClient()
    response = obj.call(json.dumps(rjson))
    return jsonify(response)

@app.route('/api/v1/db/write', methods = ['POST'])
def db_write():
    rjson = request.get_json()
    obj = WriteRpcClient()
    obj.call(json.dumps(rjson))
    return Response('{}', 200)

@app.route('/api/v1/db/clear', methods = ['POST'])
def db_clear():
    rjson = request.get_json()
    obj = ClearRpcClient()
    obj.call(json.dumps(rjson))
    return Response('{}', 200)

##ZooKeeper

@app.route('/api/v1/crash/master',methods=["POST"])
def crashmaster():
	print('[ORC] Crash Master')
	containers_list = client.containers.list()
	containers_name = []
	found = 0
	for container in containers_list:
		master = container
		cmd = master.top()['Processes'][0][7]
		if "master" in cmd:
			found = 1
			break
	if found == 1:
		pid = master.top()['Processes'][0][1]
		master.stop()
		# remome the contianer
		client.containers.prune()
		return Response(pid,status = 200)
	return Response("",status = 204)

@app.route('/api/v1/crash/slave',methods=["POST"])
def crashslave():
	print('[ORC] Crash Slave')
	containers_list = client.containers.list()
	slaves = []
	pid = 0
	print("b4 for loop")
	for container in containers_list:
		cmd = container.top()['Processes'][0][7]
		if "slave" in cmd:
			slave = container
			pid = container.top()['Processes'][0][1]
			slaves.append((pid,slave))
	print("after for loop")
	if len(slaves) > 0:
		slaves.sort(reverse = True)
		pid = slaves[0][1]
		slaves[0][1].stop()
		# remome the contianer
		client.containers.prune()

	#if pid == 0:
	#	return Response('{}',status = 204)
	return Response(pid,status = 200)

#####-   Contianer PiD list  ------######
@app.route('/api/v1/worker/list',methods=["GET"])
def list():
	print('[ORC] List Workers')
	containers_list = client.containers.list()
	containers_pid = []
	print("before loop")
	for container in containers_list:
		name = container.name
		# list of processes of the form ['UID','PID','PPID','C','STIME','TTY','TIME','CMD']
		if 'master' in name or 'slave' in name:
			process = container.top()['Processes']
			pid = str(process[0][1])
			containers_pid.append(int(pid))
	print("end of loop")
	containers_pid.sort()
	return Response(json.dumps(containers_pid),status = 200, mimetype="application/json")
######-----------------------######


if __name__ == "__main__":
    print("REACHED ORCHESTRATOR!!!!!")
    app.run(host = '0.0.0.0', debug = True)
