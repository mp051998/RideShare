#!/usr/bin/env python
import pika
import uuid
import json
import time
import requests
from flask import Flask, jsonify, request, render_template, abort, Response
import logging
from kazoo.client import KazooClient
from kazoo.client import KazooState
from waitress import serve
import threading
import uuid

time.sleep(15)

class ReadRpcClient(object):
	def __init__(self):
		self.connection = pika.BlockingConnection(
			pika.ConnectionParameters(host='master-rabbitmq', heartbeat=0))
		self.channel = self.connection.channel()

		result = self.channel.queue_declare(queue='responseQ', durable=True)
		self.callback_queue = result.method.queue

		self.channel.basic_consume(
			queue=self.callback_queue,
			on_message_callback=self.on_response,
			auto_ack=True)

	def on_response(self, ch, method, props, body):
		print("RPC Response")
		print(body)
		if self.correlation_id == props.correlation_id:
			self.response = body
			ch.basic_ack(delivery_tag=method.delivery_tag)

	def call(self, data):
		self.response = None
		self.correlation_id = str(uuid.uuid4())
		self.channel.queue_declare(queue='readQ',durable=True)
		self.channel.basic_publish(
			exchange='',
			routing_key='readQ',
			properties=pika.BasicProperties(
				reply_to=self.callback_queue,
				correlation_id=self.correlation_id,
			),
			body=data)
		while self.response is None:
			self.connection.process_data_events()
		return json.loads(self.response)

class WriteRpcClient(object):
	def __init__(self):
		self.connection = pika.BlockingConnection(
			pika.ConnectionParameters(host='master-rabbitmq', heartbeat=0))
		self.channel = self.connection.channel()

		result = self.channel.queue_declare(queue='responseQ', durable=True)
		self.callback_queue = result.method.queue

		self.channel.basic_consume(
			queue=self.callback_queue,
			on_message_callback=self.on_response,
			auto_ack=True)

	def on_response(self, ch, method, props, body):
		print("RPC Response")
		print(body)
		if self.correlation_id == props.correlation_id:
			self.response = body
			ch.basic_ack(delivery_tag=method.delivery_tag)

	def call(self, data):
		self.response = None
		self.correlation_id = str(uuid.uuid4())
		self.channel.queue_declare(queue='writeQ',durable=True)
		self.channel.basic_publish(
			exchange='',
			routing_key='writeQ',
			properties=pika.BasicProperties(
				reply_to=self.callback_queue,
				correlation_id=self.correlation_id,
			),
			body=data)
		while self.response is None:
			self.connection.process_data_events()
		return (self.response)


app = Flask(__name__)

@app.route('/api/v1/db/read', methods = ['POST'])
def db_read():
    rjson = request.get_json()
    obj = ReadRpcClient()
    response = obj.call(json.dumps(rjson))
    return jsonify(response)

@app.route('/api/v1/db/write', methods = ['POST'])
def db_write():
    rjson = request.get_json()
    obj = WriteRpcClient()
    obj.call(json.dumps(rjson))
    return Response('{}', 200)

if __name__ == "__main__":
    print("REACHED ORCHESTRATOR!!!!!")
    app.run(host = '0.0.0.0', debug = True)
