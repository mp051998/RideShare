#!/usr/bin/env python
import pika
import json
from csv import reader
from pymongo import MongoClient
import time
from kazoo.client import KazooClient
from kazoo.client import KazooState
from waitress import serve
import threading
import os

time.sleep(20)

zk = KazooClient(hosts='zoo:2181')
zk.start()

slave_name = os.environ['slave']
zk.create('/slave/'+slave_name, b'data', ephemeral=True)

connection = pika.BlockingConnection(pika.ConnectionParameters(host='master-rabbitmq', heartbeat=0))
channel = connection.channel()
channel.queue_declare(queue='readQ', durable=True)
channel.queue_declare(queue='responseQ', durable=True)
channel.queue_declare(queue='clearQsync', durable=True)

result = channel.queue_declare(queue='',durable=True)
queue_name = result.method.queue
channel.exchange_declare(exchange='sync', exchange_type='fanout')
channel.queue_bind(exchange='sync', queue=queue_name)

enums = list()
with open('AreaNameEnum.csv') as csv_file:
    csv_reader = reader(csv_file, delimiter=',')
    line_count = 0
    for row in csv_reader:
        if line_count == 0:
            line_count = 1
            continue
        enums.append(row[0].lower())

client = MongoClient("mongodb://localhost:27017/")
db = client["rideshare"]
users = db["users"]
rides = db["rides"]

def on_read_request(ch, method, properties, body):
    rjson = json.loads(body)
    if rjson["table"] == "user":
        if rjson["action"] == "check":
            found = 0
            query = users.find(rjson["data"])
            for i in query:
                if i:
                    found = 1
                    break
            ch.basic_publish(exchange='', routing_key='responseQ', properties=pika.BasicProperties(correlation_id = properties.correlation_id), body=str(found))
            ch.basic_ack(delivery_tag=method.delivery_tag)

        elif rjson["action"] == "list":
            query = users.find()
            resp = list()
            for i in query:
                resp.append(i['username'])

            ch.basic_publish(exchange='', routing_key='responseQ', properties=pika.BasicProperties(correlation_id = properties.correlation_id), body= json.dumps(resp))
            ch.basic_ack(delivery_tag=method.delivery_tag)        

    if rjson["table"] == "ride":
        if rjson["action"] == "list":
            query =  rides.find()
            resp = list()
            n = 0
            for i in query:
                n += 1
                if i['source'] == rjson['data']['source'] and i['destination'] == rjson['data']['destination']:
                    resp.append({'rideId' : f'{n}', 'username' : i['created_by'], 'timestamp' : i['timestamp']})

            ch.basic_publish(exchange='', routing_key='responseQ', properties=pika.BasicProperties(correlation_id = properties.correlation_id), body= json.dumps(resp))
            ch.basic_ack(delivery_tag=method.delivery_tag)
            return None

        elif rjson["action"] == "get":
            query=rides.find()
            resp=list()
            n = 0
            got = 0
            for i in query:
                n += 1
                if n == int(rjson["data"]):
                    resp.append({'rideId' : f'{n}', 'created_by' : i['created_by'], 'users' : i['members'], 'timestamp' : i['timestamp'],
                        'source' : i['source'], 'destination' : i['destination']})
                    ch.basic_publish(exchange='', routing_key='responseQ', properties=pika.BasicProperties(correlation_id = properties.correlation_id), body= json.dumps(resp))
                    ch.basic_ack(delivery_tag=method.delivery_tag)
                    got = 1
                    break
            if got == 0:
                ch.basic_publish(exchange='', routing_key='responseQ', properties=pika.BasicProperties(correlation_id = properties.correlation_id), body=str(0))
                ch.basic_ack(delivery_tag=method.delivery_tag)  

        elif rjson["action"] == "is_member":
            data = rjson['data']
            query=rides.find()
            success = 0
            n = 0
            for i in query:
                n += 1
                if n == int(data['id']):
                    if data["username"] in i['members']:
                        success = 1
                        break
            ch.basic_publish(exchange='', routing_key='responseQ', properties=pika.BasicProperties(correlation_id = properties.correlation_id), body=str(success))
            ch.basic_ack(delivery_tag=method.delivery_tag)

def on_write_request(ch, method, properties, body):
    rjson = json.loads(body)
    if rjson['table'] == "user":
        if rjson["action"] == "add":
            query = users.insert_one(rjson["data"])

        elif rjson["action"] == "delete":
            query = users.delete_one(rjson["data"])

    if rjson["table"] == "ride":
        if rjson["action"] == "create":
            query = rides.insert_one(rjson["data"])

        if rjson["action"] == "join":
            data = rjson['data']
            query=rides.find()
            n = 0
            success = 0
            for i in query:
                n += 1
                if n == int(data['id']):
                    y = i['members']
                    y.append(data['username'])
                    change = {"$set":{'members':y}}
                    rides.find_one_and_replace({'_id' : i['_id']}, i)
                    success = 1

        if rjson["action"] == "delete":
            query=rides.find()
            n = 0
            for i in query:
                n += 1
                if n == int(rjson['data']):
                    rides.delete_one(i)

def on_clear_request(ch, method, properties, body):         
    rides.drop()
    users.drop()

if __name__ == "__main__":
    channel.basic_consume(queue='readQ', on_message_callback=on_read_request)
    channel.basic_consume(queue=queue_name, on_message_callback=on_write_request)
    channel.basic_consume(queue='clearQsync', on_message_callback=on_clear_request)
    print(" [x] Awaiting slave read and slave sync requests")
    channel.start_consuming()
